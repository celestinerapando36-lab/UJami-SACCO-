function login() {
  alert('Login successful (prototype mode)');
  window.location.href = 'dashboard.html';
}
